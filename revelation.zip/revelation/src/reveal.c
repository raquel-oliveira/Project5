#include "reveal.h"

void printMatrixChannels(const IplImage* img, CvScalar pixel, int channels ) {
    for(int row = 0; row < img->height; row++) {
        for(int col = 0; col < img->width; col++){
            pixel = cvGet2D(img, row, col);
            if (channels == 3){
                //pixel[blue, green, red]
                printf("[%f, %f, %f] ", pixel.val[0], pixel.val[1], pixel.val[2]);
            }
            else if (channels == 1){
                printf("[%f] ", pixel.val[0]);
            }

        }
        printf("\n");
    }
}

/**
 * Reveal
 */
void reveal(const IplImage* img, CvScalar pixel, char* messageHidden, char* magic){
    int size = strlen(magic);
    char message;
    char* pmessage[2];
    char* flag = NULL;
    for(int row = 0; row < img->height; row++) {
        //for (int col = 0; col < img->width; col++) {
            pixel = cvGet2D(img, row, 0);
            printf("antes do babado da mensagem");
            message = intToChar(get_bit(pixel.val[2], 0)); //least significant red bit as char
            messageHidden = (char *) realloc(messageHidden, (strlen(messageHidden) + 2) * sizeof(char));
            printf("realloc ");
            pmessage[0] = message;
            printf("%srealloc ");
            strcat(messageHidden, pmessage); //concatenar
            printf("dei cat ");
            printf("%s ", messageHidden);
            printf("rolou mais que adelle");
       // }
    }
}

int main() {
    IplImage *img = 0;
    int height, width, step, channels;
    uchar *data;
    CvScalar pixel;

    char* magic = "HELP"; //48 45 4C 50
    char* messageHidden[1000];

    /*If second parameter == 1 (normal image); if == 0 (grey)*/
    img=cvLoadImage("../resource/withMessage.png", 1);
    if(!img){
        printf("Could not load image file: %s\n", "test.png");
        exit(0);
    }

    height    = getHeight(img);
    width     = getWidth(img);
    channels  = getChannels(img);
    data      = (uchar *)img->imageData;
    uchar *pImg = (uchar *)img->imageData; // setup the pointer to access img data

    printf("Processing a image with %d channels\n", channels);
    //printMatrixChannels(img, pixel, channels);

    //showImage(img);
    reveal(img, pixel, messageHidden, magic);

    return 0;
}