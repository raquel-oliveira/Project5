#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include "reveal.h"

int main(int argc, char *argv[]) {

    /*int opt = 0;

    static struct option long_options[] = {
            {"-fin", no_argument, 0,'f'},
            {"-in", required_argument, 0, 'i'},
            {"-out", no_argument, 0, 'o'},
            {"-b", no_argument, 0, 'b'},
            {"-c", no_argument, 0, 'c'},
            {"-p", no_argument,0,'p'},
            {"-magic", no_argument, 0, 'm'},
            {0,0,0,0}
    };

    int long_index = 0;
    while((opt = getopt_long_only(argc, argv, "", long_options, &long_index)) != -1){
        switch (opt){
            case 'f':
                break;
            case 'i':
                break;
            case 'o':
                break;
            case 'b':
                break;
            case 'c':
                break;
            case 'p':
                break;
            case 'm':
                break;
            default:
                exit(EXIT_FAILURE);
        }
    }*/
    return 0;

}
