#ifndef _FILE_H_
#define  _FILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int get_bit(char the_byte,int which_bit);

char intToChar(int a);

#endif